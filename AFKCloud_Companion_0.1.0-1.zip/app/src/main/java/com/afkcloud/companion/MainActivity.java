package com.afkcloud.companion;

import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.view.Gravity;
import android.view.ViewGroup;

public class MainActivity extends Activity {
    private static final int REQUEST_CAPTURE = 4101;
    private TextView status;
    private MediaProjectionManager projectionManager;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        projectionManager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 40, 28, 28);
        root.setBackgroundColor(Color.rgb(10, 17, 32));

        TextView title = new TextView(this);
        title.setText("AFKCloud Companion");
        title.setTextColor(Color.WHITE);
        title.setTextSize(26);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView info = new TextView(this);
        info.setText("Android 16 • Компаньон телефона\n\nЭтот первый этап проверяет системное разрешение на захват экрана. Пока передача на сервер и удалённое управление не подключены.");
        info.setTextColor(Color.LTGRAY);
        info.setTextSize(16);
        info.setPadding(0, 28, 0, 28);
        root.addView(info);

        status = new TextView(this);
        status.setText("Статус: не подключено");
        status.setTextColor(Color.rgb(100, 190, 255));
        status.setTextSize(17);
        root.addView(status);

        Button start = new Button(this);
        start.setText("Разрешить захват экрана");
        start.setOnClickListener(v -> startActivityForResult(projectionManager.createScreenCaptureIntent(), REQUEST_CAPTURE));
        root.addView(start, new LinearLayout.LayoutParams(-1, -2));

        Button stop = new Button(this);
        stop.setText("Остановить захват");
        stop.setOnClickListener(v -> {
            stopService(new Intent(this, CaptureService.class));
            status.setText("Статус: остановлено");
        });
        root.addView(stop, new LinearLayout.LayoutParams(-1, -2));

        setContentView(root);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                Intent service = new Intent(this, CaptureService.class);
                service.putExtra("resultCode", resultCode);
                service.putExtra("data", data);
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(service);
                else startService(service);
                status.setText("Статус: захват экрана разрешён");
            } else {
                status.setText("Статус: разрешение не выдано");
            }
        }
    }
}
