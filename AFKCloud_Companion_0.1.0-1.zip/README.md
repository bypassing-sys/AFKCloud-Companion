# AFKCloud Companion 0.1.0

This is an Android companion-app starter for Android 8+ (target SDK 35). It requests Android's official MediaProjection consent and starts a foreground capture service.

## Important limitations
- This APK is a local screen-capture proof of concept only.
- It does NOT yet send video to AFKCloud, receive remote input, or provide a cloud Android VM.
- Android shows its own screen-sharing indicator/notification. The user must approve each capture session.
- Android may stop or restrict capture under battery/background policies.
- Remote control requires a separately deployed, authenticated backend and a secure WebRTC/data-channel implementation. It is not included or faked here.

## Build APK with GitHub Actions
1. Create a new GitHub repository.
2. Upload the contents of this folder (not the ZIP itself) to the repository root.
3. Open the repository's **Actions** tab.
4. Select **Build AFKCloud Companion APK** and press **Run workflow** (or push to `main`).
5. Open the completed workflow run and download artifact `AFKCloud-Companion-debug`.
6. Extract the artifact and install `app-debug.apk` on your Android phone.

## Local build
Requires Android SDK and Gradle 8.11.1 with JDK 17:
`gradle :app:assembleDebug`

Package: `com.afkcloud.companion`
